
import domain.ClassString;


public class ToStringApp {
   public static void main(String []args){
      ClassString Person1 = new ClassString("mateo", 300123784, 1000);
       System.out.println("person1"+ Person1);
//       System.out.println("Nombre person1: " + Person1.getName());
//        System.out.println("Nombre person1: " + Person1.getPhone());
//         System.out.println("Nombe person1: " + Person1.getSalary());
       
   } 
}
