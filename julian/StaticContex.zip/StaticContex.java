
import domain.PersonModel;
import static domain.PersonModel.personVoid;

public class StaticContex {

    public static void main(String[] args) {
        PersonModel.personVoid = new PersonModel();
        System.out.println("person1 = " + personVoid);
        PersonModel person1 = new PersonModel("Julian");
        System.out.println("person1 = " + person1);

    }

}
