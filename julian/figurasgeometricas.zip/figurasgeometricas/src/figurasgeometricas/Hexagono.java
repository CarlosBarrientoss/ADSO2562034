package figurasgeometricas;

public class Hexagono implements Figuras {

    private double lado;

    public Hexagono(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularArea() {
        return (3.0 * Math.sqrt(3.0) * lado * lado) / 2.0;
    }

    @Override
    public double calcularPerimetro() {
        return 6 * lado;
    }
}

