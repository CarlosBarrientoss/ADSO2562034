package figurasgeometricas;

public class Figurasgeometricas {

    public static void main(String[] args) {

        Figuras triangulo = new Triangulo(10, 9);
        System.out.println("el area es: " + triangulo.calcularArea());
        System.out.println("el PerImetro es : " + triangulo.calcularPerimetro());

        Figuras cuadrado = new Cuadrado(5);
        System.out.println("el area es: " + cuadrado.calcularArea());
        System.out.println("el perImetro es: " + cuadrado.calcularPerimetro());

        Figuras circulo = new Circulo(10);
        System.out.println("el area es: " + circulo.calcularArea());
        System.out.println("el PerImetro es : " + circulo.calcularPerimetro());

        Figuras rombo = new Rombo(34, 43, 9);
        System.out.println("el area es " + rombo.calcularArea());
        System.out.println("el PerImetro es : " + rombo.calcularPerimetro());

        Figuras pentagono = new Pentagono(645);
        System.out.println("el area es: " + pentagono.calcularArea());
        System.out.println("el PerImetro es : " + pentagono.calcularPerimetro());

        Figuras hexagono = new Hexagono(89);
        System.out.println("el area es: " + hexagono.calcularArea());
        System.out.println("el PerImetro es : " + hexagono.calcularPerimetro());

        Figuras trapecio = new Trapecio(10, 9, 2, 1, 1);
        System.out.println("el area es: " + trapecio.calcularArea());
        System.out.println("el PerImetro es : " + trapecio.calcularPerimetro());

        Figuras paralelogramo = new Paralelogramo(11, 11, 23);
        System.out.println("el area es: " + paralelogramo.calcularArea());
        System.out.println("el PerImetro es : " + paralelogramo.calcularPerimetro());
    }

}
