package figurasgeometricas;

public class Pentagono implements Figuras {

    private double lado;

    public Pentagono(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularArea() {
        return (5.0 / 4.0) * lado * lado * (1.0 / Math.tan(Math.PI / 5.0));
    }

    @Override
    public double calcularPerimetro() {
        return 5 * lado;
    }
}


