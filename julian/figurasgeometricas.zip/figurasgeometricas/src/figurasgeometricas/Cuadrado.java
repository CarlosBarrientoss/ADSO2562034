
package figurasgeometricas;


public class Cuadrado implements Figuras {
    private int lado;
    
    public Cuadrado(double lado) {
        
        this.lado = (int) lado;}

    @Override
    public double calcularArea() {
        return lado * lado;
    }

    @Override
    public double calcularPerimetro() {
        return lado * lado;
    }
    
}
