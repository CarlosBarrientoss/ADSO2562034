package figurasgeometricas;

public interface Figuras {

    double calcularArea();
    double calcularPerimetro();
}
