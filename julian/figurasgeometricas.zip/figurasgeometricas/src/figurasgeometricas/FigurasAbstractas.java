package figurasgeometricas;

public class FigurasAbstractas implements Figuras {

    protected int numLados;

    public double calcularArea(int numLados) {
           
        this.numLados = numLados;
        return 0;
    
    }


 public double calcularPerimetro(int numLados) {
           
        this.numLados = numLados;
        return 0;
}

    @Override
    public double calcularArea() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double calcularPerimetro() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
