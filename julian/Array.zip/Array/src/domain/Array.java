package domain;

import java.util.Scanner;

public class Array {
    

    public static void main(String[] args, int valueSearch) {
        Scanner imput = new Scanner(System.in);
        boolean found = false;
        System.out.println("into the vale to search: ");
        int ValuesSearch = imput.nextInt();
        
        
        int number[] = new int[8];

        number[0] = 35;

        number[1] = 32;

        number[2] = 3;

        number[3] = 1;

        number[4] = 56;

        number[5] = 78;

        number[6] = 34;

        number[7] = 11;

        int numbers[] = {1, 2, 3, 4, 5, 6};

        for (int i = 0; i < numbers.length; i++) {
           // System.out.println("Numbers " + numbers[i]);
           if(numbers[i] == valueSearch){
               found = true;
               int position = numbers[i];
               
//              System.out.println("numbers "+ numbers[i]+ "found in array position"+ i);
//          /
//          
           }if (found){
               
               System.out.println("number:" + valueSearch + "not found in array");
           }
           else{
              
            
               System.out.println("numbers : not found in array");
            
             
           }
            
        }
        

        //System.out.println("Array " + number[7]);
    
    }
}
