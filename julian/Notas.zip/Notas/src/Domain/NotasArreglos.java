
package Domain;

public class NotasArreglos {
    public static double sumaNotas(double[] nota ){
        double suma = 0;
        for (int i = 0; i < nota.length; i++) {
            suma += nota[i];
        }
        return suma;
    }
    public static double porcentaje(double suma, int numPorcentaje){
        return (suma * numPorcentaje)/100;
    }
    public static double notaFinal1(double x, double y){
        return x+y;
    }
}
