
import Domain.NotasArreglos;


public class NotasApp  extends NotasArreglos{
    public static void main(String[] args) {
        double nota[] = {3.0,4.5,5.0};
        double notaFinal = 5.0;
        
        double sumatoria = sumaNotas(nota);
        System.out.println("sumatoria " + sumatoria);
        double porcentaje70 = porcentaje(sumatoria,70);
        System.out.println("Porsentaje de 70% es " + porcentaje70);
        double porcentaje30 = notaFinal1(notaFinal, 30);
        System.out.println("Porsentaje de 30% es " + porcentaje30);
        double notaDefinitiva = notaFinal1(porcentaje30,porcentaje70);
        System.out.println("Nota final es " + notaDefinitiva);
        

        
        
        
        
        
        
        
        
        
        
        
        
        
//               for (int i = 0; i < nota.length; i++){
//            System.out.println("notas " + nota[i]);
//            
//        }
        
    }
}
