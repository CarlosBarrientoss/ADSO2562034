

public class Inheritence {

    public static void main(String[] args) {
 
    }
    
}
