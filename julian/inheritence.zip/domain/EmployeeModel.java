package domain;

public class EmployeeModel extends PesonModel {

    private int idEmployee;
    private double salary;
    private static int employeecount;

    public EmployeeModel() {
    }

    public EmployeeModel(String name, double salary) {
        super(name);
        this.idEmployee = ++EmployeeModel.employeecount;
        this.salary = salary;

    }

    public int getIdEmployee() {
        return this.idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    public double getSalary() {
        return this.salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public static int getEmployeecount() {
        return employeecount;
    }

    public static void setEmployeecount(int employeecount) {
        EmployeeModel.employeecount = employeecount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("PersonModel(");
        sb.append("salary=").append(this.salary);
        sb.append("Empoyye=").append(this.idEmployee);
        sb.append(", name=").append(name);
        sb.append(", padre =").append(super.toString());
        sb.append(')');
        return sb.toString();
    }
}
