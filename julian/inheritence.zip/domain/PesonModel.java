
package domain;

public class PesonModel {
    protected String name;
    protected char gender;
    protected int age;
    protected String addres;

    public PesonModel() {
    }

    
    
    public PesonModel(String name){
        this.name = name;
    }
    
    public PesonModel(String name, char gender, int age, String addres) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.addres = addres;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getGender() {
        return this.gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddres() {
        return this.addres;
    }

    public void setAddres(String addres) {
        this.addres = addres;
    }

    @Override
    public String toString() {
        return "PesonModel{" + "name=" + name + ", gender=" + gender + ", age=" + age + ", addres=" + addres + '}';
    }
    
    
    
}
