
import domain.PesonModel;
import domain.EmployeeModel;

public class inheritanceApp {

    public static void main(String[] args) {
        // PesonModel person1 = new PesonModel();
        EmployeeModel empleado1 = new EmployeeModel("Julian", 1000000000);
        System.out.println("empleado1 = " + empleado1);

    }
}
