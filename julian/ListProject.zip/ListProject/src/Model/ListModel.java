
package Model;

import java.util.ArrayList;
import java.util.List;

public class ListModel {
    private List<Integer> listModel=new ArrayList<>();

    public List<Integer> getListModel() {
        return listModel;
    }

    public void setListModel(List<Integer> listModel) {
        this.listModel = listModel;
    }
    
}
