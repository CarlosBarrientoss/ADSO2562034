
package crud;

import java.util.List;
import java.util.Scanner;


public interface IList {
    public List<Integer> insertValues(List<Integer>  listModel, Scanner in);
    void showList(List<Integer> mostarar);
    void showListForE(List<Integer> mostrara);
    void deleFor(List<Integer> mostrara);
    void updateList(List<Integer> mostrara);
    
    
}
