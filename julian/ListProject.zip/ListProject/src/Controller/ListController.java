package Controller;


import crud.IList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ListController implements IList {

    @Override
    public List<Integer> insertValues(List<Integer> listModel, Scanner in) {
        System.out.println("Ingresando datos.. ");
        System.out.println("Ingrese la cantidad de valores de la lista:\t");
        int tamaño = in.nextInt();
        for (int i = 0; i < tamaño; i++) {
            System.out.println("Ingrese el valor:\t" + (i + 1) + ":");
            listModel.add(in.nextInt());

        }

        return listModel;
    }

    @Override
    public void showList(List<Integer> mostrara) {
//        show.ForEach(System.out.println);
        Iterator<Integer> it = mostrara.iterator();
        while (it.hasNext()) {
            System.out.println("valor: " + it.next());
        }
    }

    @Override
    public void showListForE(List<Integer> mostrara) {
        for (Integer num : mostrara) {
            System.out.println("Valor desde forE:" + num);

        }
    }

    public void insertValues(List<Integer> listModel) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleFor(List<Integer> mostrara) {
        for (Integer num : mostrara) {
            if (num == 3) {
                mostrara.remove(2);
            }
        }
    }

    public void deletFor(List<Integer> mostrara) {
        Iterator<Integer> it = mostrara.iterator();

        while (it.hasNext()) {
            if (it.next() == 3) {
                it.remove();

            }
        }

    }

    @Override
    public void updateList(List<Integer> mostrara) {
    mostrara.set(3,8);

    }
}
