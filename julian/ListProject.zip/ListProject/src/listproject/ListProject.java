package listproject;

import Controller.ListController;
import Model.ListModel;
import static java.util.Collections.list;
import java.util.List;
import java.util.Scanner;

public class ListProject {

    public static void main(String[] args) {
        ListController listController = new ListController();
        Scanner in = new Scanner(System.in);

        ListModel listModel = new ListModel();

        List<Integer> list = listController.insertValues(listModel.getListModel(), in);
        listController.showList(list);
        listController.showListForE(list);
        listController.deletFor(list);
        listController.showListForE(list);
        listController.showListForE(list);

    }

}
