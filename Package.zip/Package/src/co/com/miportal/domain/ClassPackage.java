package co.com.miportal.domain;

public class ClassPackage {

    public static void imprimir(String s) {
        System.out.println("Classpackage " + s);
    }

    public static void saludar() {
        System.out.println("Hola Julian");
    }

    public static void saludar(String hola_desde_de_un_nombre_calificado_desde_) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
