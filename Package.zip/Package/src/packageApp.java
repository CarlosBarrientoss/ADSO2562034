
import co.com.miportal.domain.ClassPackage;

public class packageApp {

    public static void main(String[] args) {
//        ClassPackage instance1 = new ClassPackage();
//        instance1.imprimir("Hola mundo instancia");

     ClassPackage.saludar();

     ClassPackage.imprimir("hola mundo:");
     co.com.miportal.domain.ClassPackage.saludar("Hola desde de un nombre calificado desde el metodo principal");
    }

}
