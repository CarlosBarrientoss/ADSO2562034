
package domain;

import java.util.Scanner;

public class ArrayClass {
    public static void main(String[] args) {
        
        Scanner imput = new Scanner(System.in);
            System.out.println("Insert value ");    
            int valueSearch = imput.nextInt();
            int numbers[] = new int [8];
            boolean founds = false;
            int position = 0;
            
            
//            
//        number[0] = 35;
//        number[1] = 32;
//        number[2] = 44;
//        number[3] = 55;
//        number[4] = 66;
//        number[5] = 77;
//        number[6] = 88;
//        number[7] = 99;
//        
       int number[] = {0,1,2,3,4,6,5};
        
        for (int i = 0; i < number.length; i++){
            
            if (number[i] == valueSearch){
                position = number[i];
                founds = true;
                
//                System.out.println("Number "+ numbers[i] + "  found in position "+ i);
//        System.out.println("Numbers " + numbers[i]);
        
        
        
        if(founds){
            System.out.println("Number "+ valueSearch +" found in array in position "+ position);
        }else{
            System.out.println("Number "+ valueSearch +" wasn't found in array");
        }
//        System.out.println("Array "+ number[7]);
    }
}
    }
}