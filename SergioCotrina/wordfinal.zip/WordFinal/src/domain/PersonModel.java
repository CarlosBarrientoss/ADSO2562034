
package domain;
public class PersonModel{
    public void saludo(){
        System.out.println(" Clase Padre ");
}
}
