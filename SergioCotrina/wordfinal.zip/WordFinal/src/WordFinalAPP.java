import domain.PersonModel;
import domain.EmployeeModel;

public class WordFinalAPP{
        
    public static void main(String[] args) {
            
        PersonModel instance = new PersonModel();
        
        EmployeeModel instance2 = new EmployeeModel();
        
        instance.saludo();
        instance2.saludo();
    }
}
