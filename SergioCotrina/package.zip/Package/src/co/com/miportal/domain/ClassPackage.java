
package co.com.miportal.domain;

public class ClassPackage {
    public static void imprimir(String s) {
        System.out.println("ClassPackage" + s);
    }
    public static void Saludar(String ss) {
        System.out.println(ss);
    }
}
