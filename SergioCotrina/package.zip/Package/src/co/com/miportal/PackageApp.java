
package co.com.miportal;
import  co.com.miportal.domain.ClassPackage;
public class PackageApp {
    public static void main(String[] args) {
        ClassPackage instance1 = new ClassPackage();  //NO ES UN PUBLIC STATIC VOID SINO PUBLIC VOID
        instance1.imprimir(" Hola mundo instancia");  //NO ES UN PUBLIC STATIC VOID SINO PUBLIC VOID


          ClassPackage.imprimir("Hola Mundo");  //ES UN PUBLIC STATIC VOID

            co.com.miportal.domain.ClassPackage.Saludar("Hola mundo 2"); //PUEDE O NO SER UN PUBLIC STATIC VOID DE TODOS MODOS SERÁ LLAMADO PORQUE ESTOY LLAMANDO DIRECTO DEL PAQUETE
    }
}
