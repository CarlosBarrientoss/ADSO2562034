import domain.PersonModel;
import domain.EmpeloyeeModel;

public class WordFinalApp extends PersonModel {
    public static void main(String[] args) {
          PersonModel instance1 = new PersonModel();
          EmpeloyeeModel instance2 = new EmpeloyeeModel();
        
          
          instance1.saludo();
          instance2.saludo();
    }
}
