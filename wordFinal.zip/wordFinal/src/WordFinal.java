
import domain.WordFinal;

public class WordFinal extends WordFinal {

    public static void main(String[] args) {

    }

}
