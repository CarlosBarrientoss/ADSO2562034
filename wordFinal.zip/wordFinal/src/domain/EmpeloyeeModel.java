package domain;

public class EmpeloyeeModel extends PersonModel {

    
    @Override
    public void saludo() {

        System.out.println("Class Hija: ");

    }

}
