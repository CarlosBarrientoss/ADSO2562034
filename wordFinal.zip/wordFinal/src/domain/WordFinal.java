
package domain;

public class WordFinal {
    public static void main(String[] args) {
        int number = 1;
        System.out.println("number" + number);
        int number2 = 2;
        System.out.println("numbre "+ number2);
    }
}
