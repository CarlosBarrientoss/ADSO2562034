
package domain;


public class PersonModel {

    private String s;
   //ATRIBUTOS
   //METODOS
    
    public void saludo(){
       
        System.out.println("Class Padre: ");
       
        
    }
}
